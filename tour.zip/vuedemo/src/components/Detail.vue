<template>
	<div class="ng-scope">
	        <div data-role="page" title="产品详情" class="ng-scope">
	            <header>
	                <a href="list.html" class="l-nav ui-icon-back"></a>
	                <router-link to="/home" class="l-nav ui-icon-back"></router-link>
	                <span>产品详情</span>
	                <a href="list.html" class=" l-nav ui-icon-home"></a>
	            </header>
	            <!-- 轮播 -->
	            <div class="m-carousel m-fluid m-carousel-photos" id="slideBox">
	                <div class="m-carousel-inner">
	                    <div class="m-item bd">
	                        <ul>
	                            <li v-for="p in list.imageList">
	                                <img :src="'/static/images/'+p.imagePath.replace('images/','')" ></li>
	                        </ul>

	                    </div>
	                    <div class="hd">
	                        <ul></ul>
	                    </div>
	                </div>

	                <div class="holiday-slider-overlayout">
	                    <span class="flag ng-binding">
	                        <span id="orgCity" v-text="list.orgCity">广州</span>
	                        -
	                        <span id="dstCity" v-text="list.dstCity">清远</span>
	                    </span>
	                    <span style="float: right;margin-right: 12px;" class="ng-binding" id="productId">编号: <span v-text="list.productId"></span></span>
	                </div>
	            </div>
	            <section class="l-content">
	                <div class="fee-title ng-binding">
	                    <span class="ng-scope ng-binding">
	                        &lt;
	                        <span id="vacationName" v-text="list.vacationName">清远古龙峡一日跟团游</span>
	                        &gt;
	                    </span>
	                    <span id="productName" v-text="list.productName">古龙峡漂流纯玩一天游</span>
	                </div>
	                <div class="price-detail">
	                    <span>
	                        促销价： <strong class="ng-binding" id="price" v-text='"￥"+list.price'>¥123</strong>
	                        起
	                    </span>
	                </div>
	                <dl class="l-article ng-pristine ng-valid">
	                    <dt>
	                        <span class="ui-ico-intro"></span>
	                        行程详情
	                    </dt>
	                    <dd class="ng-scope ng-binding">
	                        共
	                        <span id="day" v-text="list.day">1</span>
	                        天
	                        <span class="cGray999 ng-binding" id="destination" v-text="list.destination">广州-清远-广州</span>
	                        <br></dd>
	                </dl>
	                <dl class="l-article noarr">
	                    <dt>
	                        <span class="ui-icon-star"></span>
	                        产品推荐
	                    </dt>
	                    <dd class="ng-binding" id="intro" v-html="list.recommend">1、被誉为中国漂流的巅峰之作、浪尖上的过山车—古龙峡！</dd>
	                </dl>
	                <dl class="l-list l-icon-list">
	                    <dd id="feeInfo" class="ng-pristine ng-valid" style="height: auto;" @click="fee">
	                        <span class="ui-icon-rmb"></span>
	                        <span style="padding-left: 36px;">费用说明</span>
	                        <br/>
	                        <div id="fee" style="padding-left: 36px;"  v-show="flag1">
	                          <div v-html="list.feeInclude">
		                            <div class="holiday-desc">费用包含：</div>
		                            <div id="include">
		                                1、景点：李小龙乐园、逢简水乡。
		                                <br>
		                                2、用餐：二正一早餐（正餐8菜1汤,二师兄蒸猪宴30元/人、青花瓷大盘鱼40元/人）；。
		                                <br>
		                                3、住宿：鹤山碧桂园酒店（挂五星）。
		                                <br>
		                                4、交通：往返旅游巴士。
		                                <br>
		                                5、赠送：每人一支矿泉水。
		                                <br>
		                            </div>
	                            </div>
	                            <div v-html="list.feeNotInclude">
		                            <div class="holiday-desc">费用不包含：</div>
		                            <div id="not-include">
		                                1、行程外私人所产生的个人费用。
		                                <br>
		                                2、景点内游览车费用，园中园门票。
		                                <br>
		                                3、行程中的单房差费用。
		                                <br>
		                                4、个人旅游意外保险。
		                                <br>
		                                5、 小孩只含车费、半价餐、不含门票、不占床。
		                                <br>
		                                超高收费标准：
		                                <br>
		                                餐费&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; （1.4米以下已含，1.4米以上须补50元）
		                                <br>李小龙乐园 （1.4米以下已含，1.4米以上须补20元）。
		                            </div>
		                   </div>
	                        </div>
	                    </dd>
	                    <dd id="bookInfo" class="ng-pristine ng-valid" style="height: auto;" @click="book">
	                        <span class="ui-icon-note"></span>
	                        <span style="padding-left: 36px;">预订须知</span>
	                        <br/>
	                        <!-- 须知 -->
	                        <div id="book" style="padding-left: 36px;" v-html="list.importantTips"  v-show="flag2">
	                            1、车费：豪华旅游空调大巴接送。
	                            <br>
	                            2、门票：古龙峡漂流门票。
	                            <br>
	                            3、全程随车导游陪同。
	                            <br>
	                        </div>
	                    </dd>
	                </dl>
	            </section>
	            <div class="end-fixed"></div>
	    </div>
	</div>
</template>

<script>
import Vue from 'vue'
//import flexible from '../../static/js/flexible.js'
import Touch from '../../static/js/Touch.js'
export default{
	name:"Detail",
	data:function(){
		return {
			list:"",
			flag1:0,
			flag2:0,
		}
	},
	methods:{
		quest:function(id){
			var url='http://192.168.6.133:8008/interface/tour/lvyouDetail.php';
			self.ajax({
				url:url,
				type:'get',
				data:{productId:id},
				dataType:'json',
				success:function(res){
					res=JSON.parse(res);
					self.list = res.productDetail;
					document.getElementsByTagName("title")[0].innerText=res.productDetail.vacationName;
				},
				fali:function(r){
					console.log(r)
				}
			})
		},
		ajax:function(options) {
			options = options || {};
			options.type = (options.type || "GET").toUpperCase();
			options.dataType = options.dataType || "json";
			var arr = [];
			for (var name in options.data) {
			arr.push(encodeURIComponent(name) + "=" + encodeURIComponent(options.data[name]));
			}
			arr.push(("v=" + Math.random()).replace(".",""));
			var params = arr.join("&");
			//创建 - 非IE6 - 第一步
			if (window.XMLHttpRequest) {
				var xhr = new XMLHttpRequest();
			} else { //IE6及其以下版本浏览器
				var xhr = new ActiveXObject('Microsoft.XMLHTTP');
			}
			//接收 - 第三步
			xhr.onreadystatechange = function () {
				if (xhr.readyState == 4) {
					var status = xhr.status;
					if (status >= 200 && status < 300) {
						options.success && options.success(xhr.responseText, xhr.responseXML);
					} else {
						options.fail && options.fail(status);
					}
				}
			}
			//连接 和 发送 - 第二步
			if (options.type == "GET") {
				xhr.open("GET", options.url + "?" + params, true);
				xhr.send(null);
			} else if (options.type == "POST") {
				xhr.open("POST", options.url, true);
				//设置表单提交时的内容类型
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.send(params);
			}
		},
		fee:function(){
			this.flag1=!this.flag1;
		},
		book:function(){
			this.flag2=!this.flag2;
		},
	},
	created:function(){
		self = this;
		var id=location.href.split("?id=")[1];
		self.quest(id)
	},
	updated:function(){
		Touch({
			slideCell: "#slideBox",
			//开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
			titCell: ".hd ul",
			mainCell: ".bd ul",
			effect: "leftLoop",
			titOnClassName:"cur",
			autoPlay: true,
			//自动分页
			autoPage: true
		})
	}
}

</script>

<style>
@import '../../static/css/base.css';
@import '../../static/css/carousel.css';
@import '../../static/css/carousel-style.css';
@import '../../static/css/city.css';
@import '../../static/css/layout2.css';
@import '../../static/css/holiday.css';
@import '../../static/css/ticket.css';
</style>