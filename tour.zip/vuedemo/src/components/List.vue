<template>
	<div>
	<article class="article">
	  <section class="focus">
	    <div class="addWrap" id="slideBox">
	      <div class="swipe bd" id="mySwipe" style="visibility: visible;">
	        <div class="swipe-wrap" style="width: 2250px;">
	          <!--以下为渲染图片的部分-->
	          <div data-index="0" style="width: 375px; left: 0px; transition-duration: 300ms; transform: translate(-375px, 0px) translateZ(0px);">
	            <a href="#">
	              <img class="img-focus" src="../../static/images/guangfazhenqingkah5.jpg" width="100%"></a>
	          </div>
	          <div data-index="1" style="width: 375px; left: -375px; transition-duration: 300ms; transform: translate(-375px, 0px) translateZ(0px);">
	            <a href="#">
	              <img class="img-focus" src="../../static/images/changlong.jpg" width="100%"></a>
	          </div>
	          <div data-index="2" style="width: 375px; left: -750px; transition-duration: 300ms; transform: translate(-375px, 0px) translateZ(0px);">
	            <a href="#">
	              <img class="img-focus" src="../../static/images/huaxiayinhang.jpg" width="100%"></a>
	          </div>
	          <div data-index="3" style="width: 375px; left: -1125px; transition-duration: 300ms; transform: translate(0px, 0px) translateZ(0px);">
	            <a href="#">
	              <img class="img-focus" src="../../static/images/fuqiantalang.jpg" width="100%"></a>
	          </div>
	        </div>
	      </div>
	      <div class="hd">
	        <ul id="position" class="focusUl" style="color: transparent;cursor: pointer">
	          <li class="circle_li"></li>
	          <li class="circle_li"></li>
	          <li class="circle_li"></li>
	          <li class="circle_li cur"></li>
	        </ul>
	      </div>

	    </div>
	  </section>
	  <!-- 导航五模块 -->
	  <nav class="navList">
	    <ul>
	      <li data-tap="holidayInfo" @click="quest(1)">
	        <a href="#">
	          <img src="../../static/images/msite_vacation.jpg" class="index_nav">
	          <p class="colra navP">跟团游</p>
	        </a>
	      </li>
	      <li data-tap="freeInfo" @click="quest(2)">
	        <a href="#">
	          <img src="../../static/images/msite_flight.jpg" class="index_nav">
	          <p class="colra navP">自助游</p>
	        </a>
	      </li>
	      <li>
	        <a href="#">
	          <img src="../../static/images/msite_hotel.jpg" class="index_nav">
	          <p class="colra navP">酒店</p>
	        </a>
	      </li>
	      <li>
	        <a href="#">
	          <img src="../../static/images/msite_ship.jpg" class="index_nav">
	          <p class="colra navP">邮轮</p>
	        </a>
	      </li>
	      <li>
	        <a href="#">
	          <img src="../../static/images/msite_ticket.jpg" class="index_nav">
	          <p class="colra navP">门票</p>
	        </a>
	      </li>
	    </ul>
	  </nav>
	  <!-- 热门线路 -->
	  <section class="subjectList" style="">
	    <a href="javascript:void(0);" class="more">
	      <hgroup>
	        <h1 class="h1_tit left color3"> <i class="hot"></i>
	          热门线路
	        </h1>
	      </hgroup>
	    </a>
	    <ul id="ul" v-for="item in list">
			      <li :data-id="item.productId">
			      <router-link :to="'/detail?id='+item.productId">
			        <a>
			          <div class="hot_top">
			            <img src="/static/images/21.png">
			            <img :src="'/static/images/'+item.productImageUrl.replace('images/','')" class="index_img">
			            <span class="span_type orange" v-text="item.productType=='holidayInfo'?'跟团游':'自助游'">跟团游</span>
			          </div>
			          <p class="color3 left hot_bot">&lt;清远古龙峡一日跟团游&gt;古龙峡漂流纯玩一天游</p>
			          <span class="right span_price"> ￥ <b class="font14">{{item.productPrice}}起</b>
			          </span>
			        </a>
			        </router-link>
			      </li>
	    </ul>
	    <h2 class="h2_tit center colre"></h2>
	  </section>
	</article>
	</div>
</template>

<script>
import Vue from 'vue'
import VueRouter from 'vue-router'
import Touch from '../../static/js/Touch.js'
export default{
	name:"List",
	data:function(){
		return {
			list:""
		}
	},
	methods:{
		info:function(){
			console.log(this);
		},
		quest:function(index){
			var url='http://192.168.6.133:8008/interface/tour/lvyouList.php';
			self.ajax({
				url:url,
				type:'get',
				data:index==1?{tap:'holidayInfo'}:{tap:'freeInfo'},
				dataType:'json',
				success:function(res){
					res=JSON.parse(res);
					self.list = res.productList;
				},
				fali:function(r){
					console.log(r)
				}
			})
		},
		ajax:function(options) {
			options = options || {};
			options.type = (options.type || "GET").toUpperCase();
			options.dataType = options.dataType || "json";
			var arr = [];
			for (var name in options.data) {
			arr.push(encodeURIComponent(name) + "=" + encodeURIComponent(options.data[name]));
			}
			arr.push(("v=" + Math.random()).replace(".",""));
			var params = arr.join("&");

			//创建 - 非IE6 - 第一步
			if (window.XMLHttpRequest) {
				var xhr = new XMLHttpRequest();
			} else { //IE6及其以下版本浏览器
				var xhr = new ActiveXObject('Microsoft.XMLHTTP');
			}

			//接收 - 第三步
			xhr.onreadystatechange = function () {
				if (xhr.readyState == 4) {
					var status = xhr.status;
					if (status >= 200 && status < 300) {
						options.success && options.success(xhr.responseText, xhr.responseXML);
					} else {
						options.fail && options.fail(status);
					}
				}
			}

			//连接 和 发送 - 第二步
			if (options.type == "GET") {
				xhr.open("GET", options.url + "?" + params, true);
				xhr.send(null);
			} else if (options.type == "POST") {
				xhr.open("POST", options.url, true);
				//设置表单提交时的内容类型
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.send(params);
			}
		},
		//格式化参数
	},
	created:function(){
		self = this;
		self.quest(1)
	},
	updated:function(){
		Touch({
			slideCell: "#slideBox",
			//开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
			titCell: ".hd ul",
			mainCell: ".bd div",
			effect: "leftLoop",
			titOnClassName:"cur",
			autoPlay: true,
			//自动分页
			autoPage: true
		})
	}
}

</script>

<style>
@import '../../static/css/index_common.css';
@import '../../static/css/swipe.css';
@import '../../static/css/index.css';
@import '../../static/css/layout.css';
@import '../../static/css/new_index.css';
</style>
