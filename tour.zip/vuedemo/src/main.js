import Vue from 'vue'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource'
import App from './App'
import List from './components/List'
import Detail from './components/Detail'
Vue.use(VueRouter)
Vue.use(VueResource)

const routes = [{
	path:"/",
	component : List
},{
	path:"/home",
	component : List
},{
	path:"/detail",
	component : Detail
}]

const router = new VueRouter({
	routes,
})

const app = new Vue({
	el:"#app",
	router,
	...App
})